Fix or implement stacking panes: $ARGUMENTS

Steps:
1. Read docs/stacking-panes.md first
2. Confirm approach uses position: absolute (not flexbox)
3. Make changes incrementally
4. Test with 2, 3, 4 panes open
5. Verify checklist in docs/stacking-panes.md
